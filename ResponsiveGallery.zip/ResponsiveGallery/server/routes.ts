import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema, insertFranchiseSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import { ZodError } from "zod";
import { setupAuth } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);
  // Contact form submissions
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactSchema.parse(req.body);
      const contact = await storage.createContactSubmission(validatedData);
      res.status(201).json({ message: "Contact form submitted successfully", id: contact.id });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "An unexpected error occurred" });
      }
    }
  });

  // Franchise inquiries
  app.post("/api/franchise-inquiry", async (req, res) => {
    try {
      const validatedData = insertFranchiseSchema.parse(req.body);
      const inquiry = await storage.createFranchiseInquiry(validatedData);
      res.status(201).json({ message: "Franchise inquiry submitted successfully", id: inquiry.id });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "An unexpected error occurred" });
      }
    }
  });

  // Get all contact submissions (admin only - would require auth middleware in production)
  app.get("/api/admin/contacts", async (req, res) => {
    try {
      const contacts = await storage.getAllContactSubmissions();
      res.status(200).json(contacts);
    } catch (error) {
      res.status(500).json({ message: "An error occurred while fetching contact submissions" });
    }
  });

  // Get all franchise inquiries (admin only - would require auth middleware in production)
  app.get("/api/admin/franchise-inquiries", async (req, res) => {
    try {
      const inquiries = await storage.getAllFranchiseInquiries();
      res.status(200).json(inquiries);
    } catch (error) {
      res.status(500).json({ message: "An error occurred while fetching franchise inquiries" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
