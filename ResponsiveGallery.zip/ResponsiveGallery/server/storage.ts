import { 
  users, 
  type User, 
  type InsertUser, 
  contactSubmissions, 
  type InsertContact, 
  type Contact,
  franchiseInquiries,
  type InsertFranchise,
  type Franchise
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

// Interface for storage operations
export interface IStorage {
  // Session store for authentication
  sessionStore: session.Store;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Contact form operations
  createContactSubmission(contact: InsertContact): Promise<Contact>;
  getContactSubmission(id: number): Promise<Contact | undefined>;
  getAllContactSubmissions(): Promise<Contact[]>;
  
  // Franchise inquiry operations
  createFranchiseInquiry(inquiry: InsertFranchise): Promise<Franchise>;
  getFranchiseInquiry(id: number): Promise<Franchise | undefined>;
  getAllFranchiseInquiries(): Promise<Franchise[]>;
}

export class MemStorage implements IStorage {
  public sessionStore: session.Store;
  private users: Map<number, User>;
  private contacts: Map<number, Contact>;
  private franchises: Map<number, Franchise>;
  private userId: number;
  private contactId: number;
  private franchiseId: number;

  constructor() {
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    this.users = new Map();
    this.contacts = new Map();
    this.franchises = new Map();
    this.userId = 1;
    this.contactId = 1;
    this.franchiseId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Contact form methods
  async createContactSubmission(insertContact: InsertContact): Promise<Contact> {
    const id = this.contactId++;
    const submittedAt = new Date();
    const contact: Contact = { 
      ...insertContact, 
      id, 
      submittedAt,
      brandName: insertContact.brandName || null 
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async getContactSubmission(id: number): Promise<Contact | undefined> {
    return this.contacts.get(id);
  }

  async getAllContactSubmissions(): Promise<Contact[]> {
    return Array.from(this.contacts.values()).sort((a, b) => 
      b.submittedAt.getTime() - a.submittedAt.getTime()
    );
  }

  // Franchise inquiry methods
  async createFranchiseInquiry(insertFranchise: InsertFranchise): Promise<Franchise> {
    const id = this.franchiseId++;
    const submittedAt = new Date();
    const franchise: Franchise = { 
      ...insertFranchise, 
      id, 
      submittedAt,
      message: insertFranchise.message || null
    };
    this.franchises.set(id, franchise);
    return franchise;
  }

  async getFranchiseInquiry(id: number): Promise<Franchise | undefined> {
    return this.franchises.get(id);
  }

  async getAllFranchiseInquiries(): Promise<Franchise[]> {
    return Array.from(this.franchises.values()).sort((a, b) => 
      b.submittedAt.getTime() - a.submittedAt.getTime()
    );
  }
}

export const storage = new MemStorage();
