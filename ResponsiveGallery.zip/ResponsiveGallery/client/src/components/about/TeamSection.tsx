import React from 'react';
import { teamData } from '@/data/teamData';

const TeamSection: React.FC = () => {
  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto px-6 md:px-12">
        <h2 className="text-center font-playfair text-3xl md:text-4xl font-bold mb-4">OUR TEAM</h2>
        <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-12"></div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamData.map((member, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="aspect-w-1 aspect-h-1">
                <img 
                  src={member.photo} 
                  alt={member.name} 
                  className="object-cover w-full h-full"
                />
              </div>
              <div className="p-6">
                <h3 className="font-bold text-xl mb-1">{member.name}</h3>
                <p className="text-[#D4AF37] font-medium mb-3">{member.position}</p>
                <p className="text-gray-600 text-sm mb-4">{member.bio}</p>
                
                <div className="flex space-x-3">
                  {member.social.map((link, idx) => (
                    <a 
                      key={idx}
                      href={link.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-gray-400 hover:text-[#D4AF37] transition-colors"
                    >
                      <span className="sr-only">{link.platform}</span>
                      <span dangerouslySetInnerHTML={{ __html: link.icon }} />
                    </a>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TeamSection;