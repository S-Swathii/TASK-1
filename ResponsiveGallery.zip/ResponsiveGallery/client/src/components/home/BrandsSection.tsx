import React from 'react';
import { Link } from 'wouter';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import { Button } from '@/components/ui/button';
import { brandsData } from '@/data/brandsData';

const BrandsSection: React.FC = () => {
  return (
    <section id="brands" className="py-16 bg-gray-100">
      <div className="container mx-auto px-6 md:px-12">
        <h2 className="text-center font-playfair text-3xl md:text-4xl font-bold mb-4">OUR BRANDS</h2>
        <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-12"></div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {brandsData.map((brand) => (
            <div key={brand.slug} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition duration-300">
              <AspectRatio ratio={16/9}>
                <img 
                  src={brand.image} 
                  alt={brand.name} 
                  className="object-cover h-full w-full"
                />
              </AspectRatio>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{brand.name}</h3>
                <p className="text-gray-600 mb-4">{brand.shortDescription}</p>
                <Link href={`/brands/${brand.slug}`}>
                  <Button className="bg-[#D4AF37] hover:bg-[#B8860B] text-[#121212]">
                    Learn More
                  </Button>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BrandsSection;