import React from 'react';
import { Link } from 'wouter';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import { Button } from '@/components/ui/button';

const HeroSection: React.FC = () => {
  return (
    <section className="relative pt-16 md:pt-0">
      <div className="hero-slider overflow-hidden h-[60vh] md:h-[80vh]">
        <div className="relative h-full">
          <div className="absolute inset-0 bg-gradient-to-r from-[#121212] via-transparent to-[#121212] z-10"></div>
          <AspectRatio ratio={16/9} className="h-full">
            <img 
              src="https://images.unsplash.com/photo-1574484284002-952d92456975?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&q=80" 
              alt="Business professionals in a meeting" 
              className="object-cover h-full w-full"
            />
          </AspectRatio>
          <div className="absolute inset-0 flex items-center z-20">
            <div className="container mx-auto px-6 md:px-12">
              <h1 className="font-cinzel text-4xl md:text-6xl font-bold gold-text mb-4 tracking-wide">
                WELCOME TO SPR GLOBAL
              </h1>
              <p className="text-white max-w-2xl text-lg md:text-xl mb-8">
                Inspiring Lives. Empowering Communities.
              </p>
              <Link href="#brands">
                <Button className="bg-[#D4AF37] hover:bg-[#B8860B] text-[#121212] px-8 py-6 rounded-md font-medium transition duration-300 ease-in-out">
                  Explore Our Brands
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;