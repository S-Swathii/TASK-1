import React from 'react';
import { Link } from 'wouter';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import { Button } from '@/components/ui/button';
import { brandsData } from '@/data/brandsData';

const FeaturedBrandShowcase: React.FC = () => {
  // For demonstration, let's use the first brand as featured
  const featuredBrand = brandsData[0];

  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto px-6 md:px-12">
        <h2 className="text-center font-playfair text-3xl md:text-4xl font-bold mb-4">FEATURED BRAND</h2>
        <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-12"></div>
        
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="md:flex">
            <div className="md:w-1/2">
              <AspectRatio ratio={4/3}>
                <img 
                  src={featuredBrand.image}
                  alt={`${featuredBrand.name} restaurant interior`} 
                  className="h-full w-full object-cover"
                />
              </AspectRatio>
            </div>
            
            <div className="md:w-1/2 p-8">
              <div className="flex justify-center md:justify-start mb-6">
                <h3 className="text-2xl font-bold text-[#D4AF37]">{featuredBrand.name}</h3>
              </div>
              
              <p className="text-gray-700 mb-6">
                {featuredBrand.description}
              </p>
              
              <div className="mb-6">
                <h4 className="font-medium mb-2">Signature Offerings:</h4>
                <ul className="space-y-2">
                  {featuredBrand.offerings.slice(0, 3).map((offering, index) => (
                    <li key={index} className="flex items-center">
                      <div className="bg-[#D4AF37] bg-opacity-20 p-2 rounded-full mr-3">
                        <svg className="w-4 h-4 text-[#D4AF37]" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                        </svg>
                      </div>
                      <span>{offering.title}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <Link href={`/brands/${featuredBrand.slug}`}>
                <Button className="bg-[#D4AF37] hover:bg-[#B8860B] text-[#121212]">
                  Learn More About {featuredBrand.name}
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturedBrandShowcase;