import React from 'react';
import { AspectRatio } from '@/components/ui/aspect-ratio';

const IntroductionSection: React.FC = () => {
  return (
    <section className="py-12 md:py-20 bg-white">
      <div className="container mx-auto px-6 md:px-12">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h2 className="font-cinzel text-3xl md:text-4xl font-bold mb-6">
              <span className="text-[#D4AF37]">SPR</span> 
              <span className="text-[#121212]">GLOBAL</span>
            </h2>
            <p className="text-gray-700 mb-6 leading-relaxed">
              At SPR Global, we're passionate about creating exceptional experiences through our diverse portfolio of brands. From culinary delights to fitness studios, we connect communities with quality services and products.
            </p>
            <p className="text-gray-700 mb-6 leading-relaxed">
              Our mission is to inspire and empower communities through innovative business concepts that celebrate cultural heritage while embracing modern expectations. Each of our brands is built on the foundation of authenticity, quality, and customer satisfaction.
            </p>
            <p className="text-gray-700 leading-relaxed">
              We invite you to explore our brands and discover the unique experiences we've created for our valued customers. Join us on our journey as we continue to grow and expand our presence globally.
            </p>
          </div>
          
          <div className="md:w-5/12">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <AspectRatio ratio={16/9} className="rounded-lg overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80" 
                    alt="SPR Global business" 
                    className="object-cover h-full w-full"
                  />
                </AspectRatio>
              </div>
              <div>
                <AspectRatio ratio={1/1} className="rounded-lg overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1600880292089-90a7e086ee0c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80" 
                    alt="SPR Global business 2" 
                    className="object-cover h-full w-full"
                  />
                </AspectRatio>
              </div>
              <div>
                <AspectRatio ratio={1/1} className="rounded-lg overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80" 
                    alt="SPR Global business 3" 
                    className="object-cover h-full w-full"
                  />
                </AspectRatio>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default IntroductionSection;