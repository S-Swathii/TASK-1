import React from 'react';
import { Link } from 'wouter';
import { Facebook, Instagram, Linkedin, Twitter, MapPin, Phone, Mail } from 'lucide-react';
import { brandsData } from '@/data/brandsData';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#121212] py-12">
      <div className="container mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <span className="font-cinzel text-xl font-bold text-[#D4AF37]">SPR</span>
              <span className="font-cinzel text-white ml-1">GLOBAL</span>
            </div>
            <p className="text-gray-400 text-sm mb-6">
              SPR Global is a dynamic business group with a diverse portfolio of brands in the hospitality, retail, wellness, and entertainment sectors.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-[#D4AF37] transition duration-300">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#D4AF37] transition duration-300">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#D4AF37] transition duration-300">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#D4AF37] transition duration-300">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-white font-medium mb-4">LINKS</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-400 hover:text-[#D4AF37] transition duration-300">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-400 hover:text-[#D4AF37] transition duration-300">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/#brands" className="text-gray-400 hover:text-[#D4AF37] transition duration-300">
                  Our Brands
                </Link>
              </li>
              <li>
                <Link href="/business-opportunities" className="text-gray-400 hover:text-[#D4AF37] transition duration-300">
                  Business Opportunities
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-[#D4AF37] transition duration-300">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-medium mb-4">BRANDS</h3>
            <ul className="space-y-2">
              {brandsData.map((brand) => (
                <li key={brand.slug}>
                  <Link 
                    href={`/brands/${brand.slug}`} 
                    className="text-gray-400 hover:text-[#D4AF37] transition duration-300"
                  >
                    {brand.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-medium mb-4">CONTACT</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="w-5 h-5 text-[#D4AF37] mt-0.5 mr-3" />
                <span className="text-gray-400">123 Business Park, Phase 2<br />Chennai, Tamil Nadu 600001</span>
              </li>
              <li className="flex items-start">
                <Phone className="w-5 h-5 text-[#D4AF37] mt-0.5 mr-3" />
                <span className="text-gray-400">+91 44 1234 5678</span>
              </li>
              <li className="flex items-start">
                <Mail className="w-5 h-5 text-[#D4AF37] mt-0.5 mr-3" />
                <span className="text-gray-400">info@sprglobal.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <p className="text-gray-400 text-sm">© {new Date().getFullYear()} SPR Global. All rights reserved.</p>
            <div className="mt-4 md:mt-0">
              <ul className="flex space-x-6">
                <li>
                  <a href="#" className="text-gray-400 hover:text-[#D4AF37] text-sm transition duration-300">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-400 hover:text-[#D4AF37] text-sm transition duration-300">
                    Terms of Service
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-400 hover:text-[#D4AF37] text-sm transition duration-300">
                    Cookie Policy
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
