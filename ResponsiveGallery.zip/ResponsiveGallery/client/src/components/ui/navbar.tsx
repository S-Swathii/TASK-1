import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Menu, LogOut, User } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const closeMenu = () => {
    setIsOpen(false);
  };

  // Base navigation links
  const baseNavLinks = [
    { label: 'Home', path: '/' },
    { label: 'About Us', path: '/about' },
    { label: 'Our Brands', path: '/#brands' },
    { label: 'Business Opportunities', path: '/business-opportunities' },
    { label: 'Contact', path: '/contact' },
  ];
  
  // Add profile link only for authenticated users
  const navLinks = user 
    ? [...baseNavLinks, { label: 'My Profile', path: '/profile' }]
    : baseNavLinks;
    
  // Handle logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 bg-[#121212] bg-opacity-95 transition-all duration-300 ${isScrolled ? 'shadow-md' : ''}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <Link href="/" className="flex items-center">
              <span className="font-cinzel text-xl font-bold text-[#D4AF37]">SPR</span>
              <span className="font-cinzel text-white ml-1">GLOBAL</span>
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-6">
              {navLinks.map((link) => (
                <Link 
                  key={link.path} 
                  href={link.path}
                  className={`nav-link text-white hover:text-[#F5E7A3] transition duration-300 ${location === link.path ? 'text-[#D4AF37]' : ''}`}
                  onClick={(e) => {
                    if (link.path.includes('#')) {
                      e.preventDefault();
                      const target = link.path.split('#')[1];
                      const element = document.getElementById(target);
                      if (element) {
                        element.scrollIntoView({ behavior: 'smooth' });
                      } else if (location !== '/') {
                        window.location.href = link.path;
                      }
                    }
                  }}
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>
          
          {/* Auth & CTA Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            {user ? (
              <>
                <Link href="/profile">
                  <Button variant="outline" className="border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#121212] flex items-center space-x-2">
                    <User className="h-4 w-4" />
                    <span>{user.username}</span>
                  </Button>
                </Link>
                <Button 
                  onClick={handleLogout} 
                  className="bg-[#D4AF37] hover:bg-[#B8860B] text-[#121212] px-6 py-2 rounded-md text-sm font-medium transition duration-300 ease-in-out flex items-center space-x-2"
                  disabled={logoutMutation.isPending}
                >
                  <LogOut className="h-4 w-4" />
                  <span>{logoutMutation.isPending ? 'Logging out...' : 'Logout'}</span>
                </Button>
              </>
            ) : (
              <>
                <Link href="/auth/login">
                  <Button variant="outline" className="border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#121212]">
                    Login
                  </Button>
                </Link>
                <Link href="/auth/signup">
                  <Button className="bg-[#D4AF37] hover:bg-[#B8860B] text-[#121212] px-6 py-2 rounded-md text-sm font-medium transition duration-300 ease-in-out transform hover:scale-105">
                    Sign Up
                  </Button>
                </Link>
              </>
            )}
          </div>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              type="button"
              className="text-[#D4AF37] hover:text-[#F5E7A3] focus:outline-none"
              onClick={toggleMenu}
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <div className={`md:hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-[500px] opacity-100' : 'max-h-0 opacity-0 overflow-hidden'}`}>
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-[#1E1E1E]">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              href={link.path}
              className="block px-3 py-2 rounded-md text-base font-medium text-white hover:text-[#D4AF37] hover:bg-[#333333]"
              onClick={(e) => {
                closeMenu();
                if (link.path.includes('#')) {
                  e.preventDefault();
                  const target = link.path.split('#')[1];
                  const element = document.getElementById(target);
                  if (element) {
                    setTimeout(() => {
                      element.scrollIntoView({ behavior: 'smooth' });
                    }, 100);
                  } else if (location !== '/') {
                    window.location.href = link.path;
                  }
                }
              }}
            >
              {link.label}
            </Link>
          ))}
          
          {/* Auth options for mobile menu */}
          <div className="border-t border-gray-700 mt-2 pt-2">
            {user ? (
              <>
                <div className="block px-3 py-2 text-base font-medium text-[#D4AF37]">
                  Signed in as {user.username}
                </div>
                <button
                  onClick={() => {
                    handleLogout();
                    closeMenu();
                  }}
                  className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-white hover:text-[#D4AF37] hover:bg-[#333333]"
                  disabled={logoutMutation.isPending}
                >
                  {logoutMutation.isPending ? 'Logging out...' : 'Logout'}
                </button>
              </>
            ) : (
              <>
                <Link
                  href="/auth/login"
                  className="block px-3 py-2 rounded-md text-base font-medium text-white hover:text-[#D4AF37] hover:bg-[#333333]"
                  onClick={closeMenu}
                >
                  Login
                </Link>
                <Link
                  href="/auth/signup"
                  className="block px-3 py-2 rounded-md text-base font-medium text-white hover:text-[#D4AF37] hover:bg-[#333333]"
                  onClick={closeMenu}
                >
                  Sign Up
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
