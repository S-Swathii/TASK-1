import React from 'react';
import { Link } from 'wouter';
import { Brand } from '@/src/data/brandsData';

interface BrandCardProps {
  brand: Brand;
}

const BrandCard: React.FC<BrandCardProps> = ({ brand }) => {
  return (
    <div className="brand-card bg-[#1E1E1E] rounded-lg overflow-hidden shadow-lg border border-gray-800">
      <div className="p-6">
        <div className="flex justify-center mb-6">
          <h3 className="text-xl font-bold text-[#D4AF37]">{brand.name}</h3>
        </div>
        <p className="text-gray-300 text-sm mb-6 min-h-[100px]">
          {brand.shortDescription}
        </p>
        <Link 
          href={`/brands/${brand.slug}`} 
          className="text-[#D4AF37] hover:text-[#F5E7A3] transition duration-300 text-sm font-medium flex items-center justify-center"
        >
          LEARN MORE
          <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
          </svg>
        </Link>
      </div>
    </div>
  );
};

export default BrandCard;
