import React from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { brandsData } from '@/data/brandsData';

// Define form schema
const franchiseFormSchema = z.object({
  name: z.string().min(2, { message: 'Name must be at least 2 characters' }),
  email: z.string().email({ message: 'Please enter a valid email address' }),
  phone: z.string().min(10, { message: 'Please enter a valid phone number' }),
  franchise: z.string().min(1, { message: 'Please select a brand' }),
  message: z.string().optional(),
});

type FranchiseFormValues = z.infer<typeof franchiseFormSchema>;

const BusinessOpportunitiesSection: React.FC = () => {
  const { toast } = useToast();
  
  // Form setup
  const form = useForm<FranchiseFormValues>({
    resolver: zodResolver(franchiseFormSchema),
    defaultValues: {
      name: '',
      email: '',
      phone: '',
      franchise: '',
      message: '',
    },
  });

  // Submit mutation
  const mutation = useMutation({
    mutationFn: (values: FranchiseFormValues) => {
      return apiRequest('POST', '/api/franchise-inquiry', values);
    },
    onSuccess: () => {
      toast({
        title: 'Inquiry Submitted',
        description: 'Thank you for your interest! We will contact you shortly.',
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: 'Submission Failed',
        description: error.message || 'There was an error submitting your inquiry. Please try again.',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (values: FranchiseFormValues) => {
    mutation.mutate(values);
  };

  return (
    <section id="opportunities" className="py-16 bg-white">
      <div className="container mx-auto px-6 md:px-12">
        <div className="flex flex-col md:flex-row overflow-hidden relative">
          <div className="bg-[#D4AF37] py-1 px-4 text-[#121212] absolute top-10 left-0 right-0 overflow-hidden whitespace-nowrap">
            <div className="animate-marquee inline-block">
              BUSINESS OPPORTUNITIES • BUSINESS OPPORTUNITIES • BUSINESS OPPORTUNITIES • BUSINESS OPPORTUNITIES • BUSINESS OPPORTUNITIES • 
            </div>
          </div>
          
          <div className="md:w-1/2 mt-16 md:pr-12">
            <h2 className="font-playfair text-3xl font-bold mb-6">Become an Entrepreneur Today</h2>
            <h3 className="text-xl text-[#D4AF37] font-medium mb-6">Grow Your Business With SPR Global</h3>
            
            <div className="mb-8">
              <h4 className="font-medium mb-3">Franchise Options</h4>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-[#D4AF37] mt-0.5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                  </svg>
                  <span>Comprehensive training and ongoing support</span>
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-[#D4AF37] mt-0.5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                  </svg>
                  <span>Access to established and popular brands</span>
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-[#D4AF37] mt-0.5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                  </svg>
                  <span>Marketing assistance and business strategy guidance</span>
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-[#D4AF37] mt-0.5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                  </svg>
                  <span>Operational and supply chain advantages</span>
                </li>
              </ul>
            </div>
            
            <div className="mb-8">
              <h4 className="font-medium mb-3">Investment Opportunities</h4>
              <p className="text-gray-700 mb-4">
                We offer a range of investment levels across our brand portfolio, starting from ₹15 Lakhs for smaller format outlets to ₹75 Lakhs for our premier restaurants and entertainment venues.
              </p>
              <p className="text-gray-700">
                With typical ROI periods of 18-36 months and comprehensive support from our experienced team, your business will be positioned for success from day one.
              </p>
            </div>
          </div>
          
          <div className="md:w-1/2 mt-10 md:mt-16 bg-gray-50 p-6 rounded-lg shadow">
            <h3 className="text-xl font-bold mb-6">Franchise Inquiry Form</h3>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Your name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input placeholder="Your email" type="email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone</FormLabel>
                      <FormControl>
                        <Input placeholder="Your phone number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="franchise"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Franchise Interest</FormLabel>
                      <FormControl>
                        <select
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          {...field}
                        >
                          <option value="">Select a brand</option>
                          {brandsData.map((brand) => (
                            <option key={brand.slug} value={brand.name}>
                              {brand.name}
                            </option>
                          ))}
                        </select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Information</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Tell us about your business experience, location preference, etc." 
                          className="min-h-[120px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="bg-[#D4AF37] hover:bg-[#B8860B] text-[#121212] w-full"
                  disabled={mutation.isPending}
                >
                  {mutation.isPending ? 'Submitting...' : 'Submit Inquiry'}
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BusinessOpportunitiesSection;