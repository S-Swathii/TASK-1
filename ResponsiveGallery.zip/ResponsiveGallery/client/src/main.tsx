import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add global styles
import { createGlobalStyle } from "styled-components";

const GlobalStyles = createGlobalStyle`
  :root {
    --gold-light: #F5E7A3;
    --gold: #D4AF37;
    --gold-dark: #B8860B;
    --spr-black: #121212;
    --spr-darkgray: #1E1E1E;
    --spr-gray: #333333;
    --spr-lightgray: #E5E5E5;
  }

  body {
    scroll-behavior: smooth;
    font-family: 'Inter', sans-serif;
  }

  .font-cinzel {
    font-family: 'Cinzel', serif;
  }

  .font-playfair {
    font-family: 'Playfair Display', serif;
  }

  .font-inter {
    font-family: 'Inter', sans-serif;
  }

  .nav-link {
    position: relative;
  }

  .nav-link::after {
    content: '';
    position: absolute;
    width: 0;
    height: 2px;
    bottom: -2px;
    left: 0;
    background-color: #D4AF37;
    transition: width 0.3s ease;
  }

  .nav-link:hover::after {
    width: 100%;
  }

  .brand-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
  }

  .brand-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
  }
  
  .gold-text {
    background: linear-gradient(to right, #D4AF37, #F5E7A3, #D4AF37);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    background-size: 200% auto;
    animation: shine 3s linear infinite;
  }
  
  @keyframes shine {
    to {
      background-position: 200% center;
    }
  }

  .animate-marquee {
    animation: marquee 20s linear infinite;
  }

  @keyframes marquee {
    0% {
      transform: translateX(0);
    }
    100% {
      transform: translateX(-100%);
    }
  }
`;

createRoot(document.getElementById("root")!).render(
  <>
    <GlobalStyles />
    <App />
  </>
);
