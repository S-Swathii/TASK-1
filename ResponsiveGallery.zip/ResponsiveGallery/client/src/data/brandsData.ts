export interface Offering {
  title: string;
  description: string;
  image?: string;
  price?: string;
}

export interface Brand {
  name: string;
  slug: string;
  shortDescription: string;
  description: string;
  additionalInfo?: string;
  image: string;
  heroImage: string;
  detailImage?: string;
  franchiseImage?: string;
  tagline: string;
  offerings: Offering[];
  locations?: string;
  hours?: string;
  contact?: string;
  gallery?: string[];
  investment: string;
  spaceRequirement: string;
  roiPeriod: string;
}

export const brandsData: Brand[] = [
  {
    name: "CHEAPNBEST",
    slug: "cheapnbest",
    shortDescription: "A chain of affordable salons committed to providing high-quality haircuts and styling services at competitive prices, making professional grooming accessible to all.",
    description: "CHEAPNBEST is a chain of affordable salons that believes everyone deserves to look their best without breaking the bank. We provide high-quality haircuts and styling services at competitive prices, making professional grooming accessible to all. Our stylists are trained in the latest techniques and trends, ensuring that every customer leaves feeling confident and looking great.",
    additionalInfo: "Founded in 2010, CHEAPNBEST has grown from a single location to over 25 outlets across India. Our mission is to democratize personal grooming by offering premium services at affordable prices.",
    image: "https://images.unsplash.com/photo-1600948836101-f9ffda59d250?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    heroImage: "https://images.unsplash.com/photo-1562322140-8baeececf3df?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
    detailImage: "https://images.unsplash.com/photo-1589710751893-f9a6770ad71b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    tagline: "Professional Styling at Affordable Prices",
    offerings: [
      {
        title: "Basic Haircut",
        description: "Quick and efficient haircut service for those on the go.",
        image: "https://images.unsplash.com/photo-1635273051438-6525d015ddb3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: "₹149 - ₹249"
      },
      {
        title: "Premium Styling",
        description: "Complete styling including wash, cut, and blow-dry.",
        image: "https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: "₹299 - ₹499"
      },
      {
        title: "Color Services",
        description: "Professional hair coloring using premium products.",
        image: "https://images.unsplash.com/photo-1605497788044-5a32c7078486?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: "₹499 - ₹1499"
      }
    ],
    locations: "25+ locations across India",
    hours: "Monday-Saturday: 9:00 AM - 8:00 PM, Sunday: 10:00 AM - 6:00 PM",
    contact: "info@cheapnbest.com | +91 98765 43210",
    gallery: [
      "https://images.unsplash.com/photo-1622286342621-4bd786c2447c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1599351431202-1e0f0137899a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1560066984-138dadb4c035?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    ],
    investment: "₹15-25 Lakhs",
    spaceRequirement: "400-800 sq. ft.",
    roiPeriod: "18-24 months"
  },
  {
    name: "Sulthan's Biryani",
    slug: "sulthans-biryani",
    shortDescription: "Authentic biryani restaurant offering a rich heritage of flavors with premium ingredients and traditional cooking methods, delivering the royal taste of authentic biryanis.",
    description: "Sulthan's Biryani is an authentic culinary destination that celebrates the rich heritage of biryani. We use only premium ingredients and traditional cooking methods to deliver the royal taste of authentic biryanis. Each dish is crafted with care, honoring centuries-old recipes and techniques that have been passed down through generations.",
    additionalInfo: "Our chefs bring decades of experience in perfecting the art of biryani preparation. We pride ourselves on using aromatic long-grain basmati rice, premium meats, and a secret blend of spices to create our signature dishes.",
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    heroImage: "https://images.unsplash.com/photo-1633633749892-722171802407?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
    detailImage: "https://images.unsplash.com/photo-1633633549233-9c896a0edc08?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    tagline: "Taste the Royal Heritage",
    offerings: [
      {
        title: "Hyderabadi Dum Biryani",
        description: "Slow-cooked in sealed pots, allowing the flavors to intensify and meld together.",
        image: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: "₹299 - ₹599"
      },
      {
        title: "Lucknowi Biryani",
        description: "Known for its subtle flavors, aromatic spices, and tender meat.",
        image: "https://images.unsplash.com/photo-1630851840633-f96999247032?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: "₹329 - ₹629"
      },
      {
        title: "Mughlai Specialties",
        description: "Rich, creamy curries and kebabs that complement our biryanis perfectly.",
        image: "https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: "₹199 - ₹499"
      }
    ],
    locations: "15+ locations across India",
    hours: "Daily: 11:00 AM - 11:00 PM",
    contact: "info@sulthansbiryani.com | +91 98765 12345",
    gallery: [
      "https://images.unsplash.com/photo-1642973720603-f6f253bf854f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1593854823322-5a767b9b99bb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1567188040759-fb8a6a78568a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    ],
    investment: "₹30-50 Lakhs",
    spaceRequirement: "1000-1500 sq. ft.",
    roiPeriod: "24-36 months"
  },
  {
    name: "The Ponnusamy Elite",
    slug: "ponnusamy-elite",
    shortDescription: "Upscale dining experience featuring authentic South Indian cuisine with a modern twist, celebrating the rich culinary heritage with premium ingredients and impeccable service.",
    description: "The Ponnusamy Elite offers an upscale dining experience featuring authentic South Indian cuisine with a modern twist. We celebrate the rich culinary heritage of South India with premium ingredients and impeccable service. Our chefs have mastered traditional recipes while bringing contemporary presentations to create a unique dining experience.",
    image: "https://images.unsplash.com/photo-1514933651103-005eec06c04b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    heroImage: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
    detailImage: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    tagline: "South Indian Cuisine, Reimagined",
    offerings: [
      {
        title: "Signature Dosa Platter",
        description: "A selection of gourmet dosas with innovative fillings and accompaniments.",
        image: "https://images.unsplash.com/photo-1610192244261-3f33de3f72e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: "₹349 - ₹599"
      },
      {
        title: "Premium Thali Experience",
        description: "A curated selection of South Indian delicacies served on a traditional thali.",
        image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: "₹499 - ₹899"
      },
      {
        title: "Seafood Specialties",
        description: "Fresh seafood prepared with traditional South Indian spices and techniques.",
        image: "https://images.unsplash.com/photo-1626200513389-ee9596e9ac05?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: "₹599 - ₹1299"
      }
    ],
    locations: "8 locations across major cities",
    hours: "Daily: 12:00 PM - 3:30 PM, 7:00 PM - 11:00 PM",
    contact: "reservations@ponnusamyelite.com | +91 98765 98765",
    gallery: [
      "https://images.unsplash.com/photo-1570461226513-e63ea1e3773c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1585937421612-70a008356fbe?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1601050690597-df0568f70950?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    ],
    investment: "₹70-90 Lakhs",
    spaceRequirement: "1500-2500 sq. ft.",
    roiPeriod: "30-42 months"
  },
  {
    name: "Jonah's Bistro",
    slug: "jonahs-bistro",
    shortDescription: "Contemporary bistro offering international cuisine with a focus on fusion flavors, craft beverages, and a warm, inviting atmosphere perfect for casual dining and social gatherings.",
    description: "Jonah's Bistro is a contemporary dining destination offering international cuisine with a focus on fusion flavors. We combine culinary traditions from around the world to create innovative, delicious dishes in a warm, inviting atmosphere perfect for casual dining and social gatherings. Our craft beverages complement the menu, creating a complete dining experience.",
    image: "https://images.unsplash.com/photo-1530796774133-91a283b77e75?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    heroImage: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
    detailImage: "https://images.unsplash.com/photo-1569096651661-820d0de8b4ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    tagline: "Global Flavors, Local Heart",
    offerings: [
      {
        title: "Signature Fusion Bowls",
        description: "Nutritious and flavorful bowls combining elements from various world cuisines.",
        image: "https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: "₹349 - ₹449"
      },
      {
        title: "Gourmet Burgers & Sandwiches",
        description: "Handcrafted burgers and sandwiches with international flavor profiles.",
        image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: "₹299 - ₹499"
      },
      {
        title: "Craft Cocktails",
        description: "Innovative cocktails featuring house-made infusions and premium spirits.",
        image: "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        price: "₹249 - ₹549"
      }
    ],
    locations: "10 locations in metropolitan areas",
    hours: "Monday-Sunday: 11:00 AM - 11:00 PM",
    contact: "hello@jonahsbistro.com | +91 98765 54321",
    gallery: [
      "https://images.unsplash.com/photo-1592861956120-e524fc739696?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1600335895229-6e75511892c8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1560750588-73207b1ef5b8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    ],
    investment: "₹50-70 Lakhs",
    spaceRequirement: "1200-2000 sq. ft.",
    roiPeriod: "24-36 months"
  },
  {
    name: "FunzXtreme",
    slug: "funzxtreme",
    shortDescription: "Family entertainment center offering a wide range of activities including arcade games, virtual reality experiences, and adventure zones designed for all ages.",
    description: "FunzXtreme is a premier family entertainment center offering a wide range of activities designed for all ages. From arcade games and virtual reality experiences to adventure zones and party spaces, we provide the perfect setting for family outings, birthdays, and special occasions. Our state-of-the-art facilities are designed to create unforgettable memories for visitors of all ages.",
    image: "https://images.unsplash.com/photo-1659161060074-5d14a2a9efe8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    heroImage: "https://images.unsplash.com/photo-1544979590-37e9b47eb705?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
    franchiseImage: "https://images.unsplash.com/photo-1563803835717-b6f2b513ff73?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    tagline: "Where Fun Knows No Limits",
    offerings: [
      {
        title: "Arcade Zone",
        description: "The latest arcade games and prize redemption machines for all ages.",
        image: "https://images.unsplash.com/photo-1560809451-9a23e79f3332?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
      },
      {
        title: "VR Experience Zone",
        description: "State-of-the-art virtual reality games and experiences.",
        image: "https://images.unsplash.com/photo-1478416272538-5f7e51dc5400?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
      },
      {
        title: "Adventure Park",
        description: "Indoor adventure activities including trampolines, climbing walls, and obstacle courses.",
        image: "https://images.unsplash.com/photo-1472457974886-0ebcd59440cc?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
      }
    ],
    locations: "12 centers across the country",
    hours: "Monday-Friday: 11:00 AM - 9:00 PM, Weekends: 10:00 AM - 11:00 PM",
    contact: "fun@funzxtreme.com | +91 98765 87654",
    gallery: [
      "https://images.unsplash.com/photo-1561424412-6d9e7f7ff7ad?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1519143605576-3d9e44fc234d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1526035248732-6b6c159ee84a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    ],
    investment: "₹1-2 Crores",
    spaceRequirement: "5000-10000 sq. ft.",
    roiPeriod: "36-48 months"
  },
  {
    name: "Siam Fitness Studio",
    slug: "siam-fitness",
    shortDescription: "Modern fitness center focused on Thai-inspired workouts, including Muay Thai, comprehensive fitness programs, and wellness services in a motivating environment.",
    description: "Siam Fitness Studio is a modern fitness center focused on Thai-inspired workouts and comprehensive fitness programs. We offer a range of classes including Muay Thai, functional training, yoga, and personalized training sessions. Our skilled instructors and motivating environment help members achieve their fitness goals while experiencing the discipline and effectiveness of Thai fitness traditions.",
    image: "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    heroImage: "https://images.unsplash.com/photo-1549060279-7e168fcee0c2?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
    detailImage: "https://images.unsplash.com/photo-1576678927484-cc907957088c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    tagline: "Discipline. Strength. Transformation.",
    offerings: [
      {
        title: "Muay Thai Classes",
        description: "Authentic Muay Thai training for all skill levels, from beginners to advanced practitioners.",
        image: "https://images.unsplash.com/photo-1557692538-9511bbc34dd0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
      },
      {
        title: "Functional Fitness",
        description: "High-intensity workouts focused on improving strength, endurance, and overall fitness.",
        image: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
      },
      {
        title: "Wellness Programs",
        description: "Comprehensive wellness services including nutrition counseling and recovery sessions.",
        image: "https://images.unsplash.com/photo-1532446753548-292d17da32b1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
      }
    ],
    locations: "9 studios in urban centers",
    hours: "Monday-Friday: 6:00 AM - 10:00 PM, Weekends: 7:00 AM - 8:00 PM",
    contact: "train@siamfitness.com | +91 98765 34567",
    gallery: [
      "https://images.unsplash.com/photo-1518611012118-696072aa579a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1599058917212-d750089bc07e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    ],
    investment: "₹40-60 Lakhs",
    spaceRequirement: "2000-3500 sq. ft.",
    roiPeriod: "24-36 months"
  }
];
