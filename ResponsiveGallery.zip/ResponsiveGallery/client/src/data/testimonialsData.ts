export interface Testimonial {
  name: string;
  role: string;
  quote: string;
  avatar: string;
}

export const testimonialsData: Testimonial[] = [
  {
    name: "Raj Malhotra",
    role: "Franchise Owner, Bangalore",
    quote: "Partnering with SPR Global for our Sulthan's Biryani franchise has been a game-changer. Their operational support and marketing expertise have helped us exceed our revenue targets within the first year.",
    avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&q=80"
  },
  {
    name: "Priya Sharma",
    role: "Franchise Owner, Mumbai",
    quote: "The training and support from SPR Global has been incredible. Our CHEAPNBEST salon is now one of the most popular in the area, and we're already planning to open a second location.",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&q=80"
  },
  {
    name: "Vikram Singh",
    role: "Franchise Owner, Chennai",
    quote: "FunzXtreme has been a tremendous success in our area. The SPR team's guidance on equipment selection, staff training, and marketing has been invaluable. Our ROI has exceeded expectations.",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&q=80"
  },
  {
    name: "Ananya Patel",
    role: "Franchise Owner, Delhi",
    quote: "Operating a Siam Fitness Studio franchise has transformed my career. SPR Global provided comprehensive training and continuous support that helped me build a thriving community of fitness enthusiasts.",
    avatar: "https://images.unsplash.com/photo-1548142813-c348350df52b?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&q=80"
  },
  {
    name: "Karthik Reddy",
    role: "Franchise Owner, Hyderabad",
    quote: "The Ponnusamy Elite franchise has exceeded all my expectations. The SPR Global team understands the restaurant business deeply and provided invaluable support in establishing our premium dining experience.",
    avatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&q=80"
  },
  {
    name: "Leela Nair",
    role: "Franchise Owner, Kochi",
    quote: "Jonah's Bistro has been a perfect fit for our neighborhood. The concept is fresh and appealing, and the SPR Global team has been alongside us every step of the way from setup to daily operations.",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&q=80"
  }
];
