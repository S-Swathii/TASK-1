import React from 'react';
import HeroSection from '@/components/home/HeroSection';
import IntroductionSection from '@/components/home/IntroductionSection';
import BrandsSection from '@/components/home/BrandsSection';
import FeaturedBrandShowcase from '@/components/home/FeaturedBrandShowcase';
import TestimonialsSection from '@/components/home/TestimonialsSection';
import ContactForm from '@/components/contact/ContactForm';

const Home: React.FC = () => {
  return (
    <div>
      <HeroSection />
      <IntroductionSection />
      <BrandsSection />
      <FeaturedBrandShowcase />
      <TestimonialsSection />
      
      {/* Contact Section */}
      <section id="contact" className="py-16 bg-white">
        <div className="container mx-auto px-6 md:px-12">
          <h2 className="text-center font-playfair text-3xl md:text-4xl font-bold mb-4">GET IN TOUCH</h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-12"></div>
          <ContactForm />
        </div>
      </section>
    </div>
  );
};

export default Home;
