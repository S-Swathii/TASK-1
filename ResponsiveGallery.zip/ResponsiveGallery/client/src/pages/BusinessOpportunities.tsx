import React from 'react';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import BusinessOpportunitiesSection from '@/components/business/BusinessOpportunitiesSection';
import { brandsData } from '@/data/brandsData';

const BusinessOpportunities: React.FC = () => {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative">
        <div className="bg-[#121212] h-[40vh] md:h-[50vh] relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-[#121212] via-transparent to-[#121212] z-10"></div>
          <AspectRatio ratio={16/9} className="h-full">
            <img 
              src="https://images.unsplash.com/photo-1560179707-f14e90ef3623?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&q=80" 
              alt="Business opportunity" 
              className="object-cover h-full w-full"
            />
          </AspectRatio>
          <div className="absolute inset-0 flex items-center z-20">
            <div className="container mx-auto px-6 md:px-12">
              <h1 className="font-cinzel text-4xl md:text-6xl font-bold gold-text mb-4 tracking-wide">
                BUSINESS OPPORTUNITIES
              </h1>
              <p className="text-white max-w-2xl text-lg md:text-xl">
                Partner with SPR Global to grow your business
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Business Opportunities Section */}
      <BusinessOpportunitiesSection />

      {/* Available Franchises Section */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-6 md:px-12">
          <h2 className="text-center font-playfair text-3xl md:text-4xl font-bold mb-4">AVAILABLE FRANCHISES</h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-12"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {brandsData.map((brand) => (
              <div key={brand.slug} className="bg-white rounded-lg shadow-lg overflow-hidden">
                <AspectRatio ratio={16/9}>
                  <img 
                    src={brand.image} 
                    alt={brand.name} 
                    className="object-cover h-full w-full"
                  />
                </AspectRatio>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{brand.name}</h3>
                  <p className="text-gray-600 mb-4">{brand.shortDescription}</p>
                  
                  <div className="mb-4">
                    <h4 className="font-medium text-sm text-gray-500 mb-2">INVESTMENT REQUIRED</h4>
                    <p className="text-[#D4AF37] font-bold">{brand.investment}</p>
                  </div>
                  
                  <div className="mb-4">
                    <h4 className="font-medium text-sm text-gray-500 mb-2">SPACE REQUIREMENT</h4>
                    <p className="font-medium">{brand.spaceRequirement}</p>
                  </div>
                  
                  <div className="mb-4">
                    <h4 className="font-medium text-sm text-gray-500 mb-2">ROI PERIOD</h4>
                    <p className="font-medium">{brand.roiPeriod}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6 md:px-12">
          <div className="flex flex-col md:flex-row md:items-center gap-12">
            <div className="md:w-1/2">
              <h2 className="font-cinzel text-3xl md:text-4xl font-bold mb-6">
                <span className="text-[#D4AF37]">WHY</span> 
                <span className="text-[#121212]"> PARTNER WITH US</span>
              </h2>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="bg-[#D4AF37] bg-opacity-20 p-3 rounded-full mr-4">
                    <svg className="w-6 h-6 text-[#D4AF37]" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-2">Proven Business Models</h3>
                    <p className="text-gray-600">Our brands have established customer bases and solid operational frameworks that have been tested and refined over years.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[#D4AF37] bg-opacity-20 p-3 rounded-full mr-4">
                    <svg className="w-6 h-6 text-[#D4AF37]" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"></path>
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-2">Comprehensive Training & Support</h3>
                    <p className="text-gray-600">We provide extensive training for you and your staff, along with ongoing operational support to ensure your success.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[#D4AF37] bg-opacity-20 p-3 rounded-full mr-4">
                    <svg className="w-6 h-6 text-[#D4AF37]" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd"></path>
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-2">Marketing Expertise</h3>
                    <p className="text-gray-600">Access our marketing resources and expertise to help promote your business and attract customers.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[#D4AF37] bg-opacity-20 p-3 rounded-full mr-4">
                    <svg className="w-6 h-6 text-[#D4AF37]" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clipRule="evenodd"></path>
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-2">Supply Chain Advantages</h3>
                    <p className="text-gray-600">Benefit from our established supplier relationships and bulk purchasing power for better margins.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="md:w-1/2">
              <AspectRatio ratio={4/3} className="rounded-lg overflow-hidden shadow-xl">
                <img 
                  src="https://images.unsplash.com/photo-1577962917302-cd874c4e31d2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80" 
                  alt="Business partnership" 
                  className="object-cover h-full w-full"
                />
              </AspectRatio>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default BusinessOpportunities;
