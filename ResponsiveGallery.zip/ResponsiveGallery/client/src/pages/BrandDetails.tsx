import React from 'react';
import { useRoute, Link } from 'wouter';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import { Button } from '@/components/ui/button';
import { brandsData } from '@/data/brandsData';
import ContactForm from '@/components/contact/ContactForm';
import { MapPin, Clock, Phone } from 'lucide-react';

const BrandDetails: React.FC = () => {
  // Get the brand slug from the URL
  const [, params] = useRoute('/brands/:slug');
  const slug = params?.slug;

  // Find the brand with the matching slug
  const brand = brandsData.find(b => b.slug === slug);

  // If brand is not found, render a not found message
  if (!brand) {
    return (
      <div className="container mx-auto px-6 md:px-12 py-24 text-center">
        <h1 className="text-3xl font-bold mb-4">Brand Not Found</h1>
        <p className="mb-8">Sorry, we couldn't find the brand you're looking for.</p>
        <Link href="/">
          <Button className="bg-[#D4AF37] hover:bg-[#B8860B] text-[#121212]">
            Return to Home
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative">
        <div className="bg-[#121212] h-[50vh] md:h-[60vh] relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-[#121212] via-transparent to-[#121212] z-10"></div>
          <AspectRatio ratio={16/9} className="h-full">
            <img 
              src={brand.heroImage} 
              alt={brand.name} 
              className="object-cover h-full w-full"
            />
          </AspectRatio>
          <div className="absolute inset-0 flex items-center z-20">
            <div className="container mx-auto px-6 md:px-12">
              <h1 className="font-cinzel text-4xl md:text-6xl font-bold gold-text mb-4 tracking-wide">
                {brand.name.toUpperCase()}
              </h1>
              <p className="text-white max-w-2xl text-lg md:text-xl">
                {brand.tagline}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Brand Introduction */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6 md:px-12">
          <div className="flex flex-col md:flex-row gap-12">
            <div className="md:w-1/2">
              <h2 className="font-cinzel text-3xl md:text-4xl font-bold mb-6">
                <span className="text-[#D4AF37]">ABOUT</span> 
                <span className="text-[#121212]"> THE BRAND</span>
              </h2>
              <p className="text-gray-700 mb-6 leading-relaxed">
                {brand.description}
              </p>
              
              {brand.additionalInfo && (
                <p className="text-gray-700 mb-6 leading-relaxed">
                  {brand.additionalInfo}
                </p>
              )}
              
              <div className="space-y-4">
                {brand.locations && (
                  <div className="flex items-start">
                    <MapPin className="w-5 h-5 text-[#D4AF37] mt-1 mr-3" />
                    <div>
                      <h4 className="font-medium mb-1">Locations</h4>
                      <p className="text-gray-600">{brand.locations}</p>
                    </div>
                  </div>
                )}
                
                {brand.hours && (
                  <div className="flex items-start">
                    <Clock className="w-5 h-5 text-[#D4AF37] mt-1 mr-3" />
                    <div>
                      <h4 className="font-medium mb-1">Business Hours</h4>
                      <p className="text-gray-600">{brand.hours}</p>
                    </div>
                  </div>
                )}
                
                {brand.contact && (
                  <div className="flex items-start">
                    <Phone className="w-5 h-5 text-[#D4AF37] mt-1 mr-3" />
                    <div>
                      <h4 className="font-medium mb-1">Contact</h4>
                      <p className="text-gray-600">{brand.contact}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            <div className="md:w-1/2">
              <AspectRatio ratio={4/3} className="rounded-lg overflow-hidden shadow-lg">
                <img 
                  src={brand.detailImage || brand.image} 
                  alt={`${brand.name} interior`} 
                  className="object-cover h-full w-full"
                />
              </AspectRatio>
            </div>
          </div>
        </div>
      </section>

      {/* Signature Offerings */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-6 md:px-12">
          <h2 className="text-center font-playfair text-3xl md:text-4xl font-bold mb-4">SIGNATURE OFFERINGS</h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-12"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {brand.offerings.map((offering, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                {offering.image && (
                  <AspectRatio ratio={16/9}>
                    <img 
                      src={offering.image} 
                      alt={offering.title} 
                      className="object-cover h-full w-full"
                    />
                  </AspectRatio>
                )}
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{offering.title}</h3>
                  <p className="text-gray-600 mb-4">{offering.description}</p>
                  {offering.price && (
                    <p className="text-[#D4AF37] font-bold">{offering.price}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      {brand.gallery && brand.gallery.length > 0 && (
        <section className="py-16 bg-white">
          <div className="container mx-auto px-6 md:px-12">
            <h2 className="text-center font-playfair text-3xl md:text-4xl font-bold mb-4">GALLERY</h2>
            <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-12"></div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {brand.gallery.map((image, index) => (
                <div key={index} className="rounded-lg overflow-hidden shadow-md">
                  <AspectRatio ratio={1/1}>
                    <img 
                      src={image} 
                      alt={`${brand.name} gallery image ${index + 1}`}
                      className="object-cover h-full w-full hover:scale-105 transition-transform duration-300"
                    />
                  </AspectRatio>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Franchise Opportunities */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-6 md:px-12">
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="p-8">
              <h2 className="font-cinzel text-3xl font-bold mb-6">
                <span className="text-[#D4AF37]">FRANCHISE</span> 
                <span className="text-[#121212]"> OPPORTUNITIES</span>
              </h2>
              
              <div className="flex flex-col md:flex-row gap-12">
                <div className="md:w-2/3">
                  <p className="text-gray-700 mb-6 leading-relaxed">
                    Interested in opening your own {brand.name} franchise? Join our growing family of successful business owners and benefit from our proven business model, comprehensive training, and ongoing support.
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div className="bg-gray-50 p-4 rounded-md">
                      <h4 className="font-medium mb-2">Investment Required</h4>
                      <p className="text-[#D4AF37] font-bold">{brand.investment}</p>
                    </div>
                    
                    <div className="bg-gray-50 p-4 rounded-md">
                      <h4 className="font-medium mb-2">Space Requirement</h4>
                      <p className="font-medium">{brand.spaceRequirement}</p>
                    </div>
                    
                    <div className="bg-gray-50 p-4 rounded-md">
                      <h4 className="font-medium mb-2">ROI Period</h4>
                      <p className="font-medium">{brand.roiPeriod}</p>
                    </div>
                  </div>
                  
                  <Link href="/business-opportunities">
                    <Button className="bg-[#D4AF37] hover:bg-[#B8860B] text-[#121212]">
                      Learn More About Franchise Opportunities
                    </Button>
                  </Link>
                </div>
                
                <div className="md:w-1/3">
                  <AspectRatio ratio={3/4} className="rounded-md overflow-hidden">
                    <img 
                      src={brand.franchiseImage || brand.image} 
                      alt={`${brand.name} franchise opportunity`} 
                      className="object-cover h-full w-full"
                    />
                  </AspectRatio>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6 md:px-12">
          <h2 className="text-center font-playfair text-3xl md:text-4xl font-bold mb-4">GET IN TOUCH</h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-12"></div>
          
          <div className="max-w-2xl mx-auto">
            <ContactForm brandName={brand.name} />
          </div>
        </div>
      </section>
    </div>
  );
};

export default BrandDetails;
