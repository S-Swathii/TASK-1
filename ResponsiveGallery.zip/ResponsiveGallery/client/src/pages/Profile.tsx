import React, { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';

interface UserProfile {
  name: string;
  email: string;
  phone: string;
  address: string;
  interests: string[];
}

const Profile: React.FC = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  
  // Initialize with defaults that will be replaced once user is loaded
  const [userProfile, setUserProfile] = useState<UserProfile>({
    name: user?.username || '',
    email: user?.email || '',
    phone: user?.phone || '',
    address: user?.address || '',
    interests: user?.interests || ['Restaurant Franchises', 'Fitness Centers', 'Entertainment']
  });

  const [formData, setFormData] = useState<UserProfile>(userProfile);
  
  // Update profile data when user changes
  useEffect(() => {
    if (user) {
      const updatedProfile = {
        name: user.username || '',
        email: user.email || '',
        phone: user.phone || '',
        address: user.address || '',
        interests: user.interests || ['Restaurant Franchises', 'Fitness Centers', 'Entertainment']
      };
      setUserProfile(updatedProfile);
      setFormData(updatedProfile);
    }
  }, [user]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleInterestChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, checked } = e.target;
    
    if (checked) {
      setFormData(prev => ({
        ...prev,
        interests: [...prev.interests, value]
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        interests: prev.interests.filter(interest => interest !== value)
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setUserProfile(formData);
    setIsEditing(false);
    
    toast({
      title: 'Profile Updated',
      description: 'Your profile information has been updated successfully.',
    });
  };

  return (
    <div className="py-12 md:py-20 bg-white">
      <div className="container mx-auto px-6 md:px-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-8">My Profile</h1>
        
        <div className="bg-gray-50 rounded-lg shadow p-8">
          {!isEditing ? (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-semibold">Personal Information</h2>
                <button 
                  onClick={() => setIsEditing(true)}
                  className="bg-[#D4AF37] hover:bg-[#B8860B] text-[#121212] px-4 py-2 rounded-md font-medium transition duration-300 ease-in-out"
                >
                  Edit Profile
                </button>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-gray-500 font-medium mb-2">Name</h3>
                  <p className="text-gray-800 mb-4">{userProfile.name}</p>
                  
                  <h3 className="text-gray-500 font-medium mb-2">Email</h3>
                  <p className="text-gray-800 mb-4">{userProfile.email}</p>
                  
                  <h3 className="text-gray-500 font-medium mb-2">Phone</h3>
                  <p className="text-gray-800 mb-4">{userProfile.phone}</p>
                </div>
                
                <div>
                  <h3 className="text-gray-500 font-medium mb-2">Address</h3>
                  <p className="text-gray-800 mb-4">{userProfile.address}</p>
                  
                  <h3 className="text-gray-500 font-medium mb-2">Interests</h3>
                  <div className="flex flex-wrap gap-2">
                    {userProfile.interests.map((interest, index) => (
                      <span 
                        key={index}
                        className="bg-[#D4AF37] bg-opacity-10 text-[#B8860B] px-3 py-1 rounded-full text-sm"
                      >
                        {interest}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-semibold">Edit Profile</h2>
                <div className="space-x-4">
                  <button 
                    type="button"
                    onClick={() => {
                      setIsEditing(false);
                      setFormData(userProfile);
                    }}
                    className="bg-gray-200 hover:bg-gray-300 text-gray-800 px-4 py-2 rounded-md font-medium transition duration-300 ease-in-out"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="bg-[#D4AF37] hover:bg-[#B8860B] text-[#121212] px-4 py-2 rounded-md font-medium transition duration-300 ease-in-out"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <div className="mb-4">
                    <label htmlFor="name" className="block text-gray-700 font-medium mb-2">Name</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                    />
                  </div>
                  
                  <div className="mb-4">
                    <label htmlFor="email" className="block text-gray-700 font-medium mb-2">Email</label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                    />
                  </div>
                  
                  <div className="mb-4">
                    <label htmlFor="phone" className="block text-gray-700 font-medium mb-2">Phone</label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                    />
                  </div>
                </div>
                
                <div>
                  <div className="mb-4">
                    <label htmlFor="address" className="block text-gray-700 font-medium mb-2">Address</label>
                    <textarea
                      id="address"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      rows={4}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Interests</label>
                    <div className="space-y-2">
                      {['Restaurant Franchises', 'Salon Services', 'Fitness Centers', 'Entertainment', 'Retail Stores'].map((interest) => (
                        <label key={interest} className="flex items-center">
                          <input
                            type="checkbox"
                            value={interest}
                            checked={formData.interests.includes(interest)}
                            onChange={handleInterestChange}
                            className="mr-2 h-5 w-5 text-[#D4AF37] focus:ring-[#D4AF37]"
                          />
                          {interest}
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </form>
          )}
        </div>
        
        <div className="mt-8 bg-gray-50 rounded-lg shadow p-8">
          <h2 className="text-2xl font-semibold mb-6">Your Inquiries</h2>
          
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white rounded-lg overflow-hidden">
              <thead className="bg-gray-100">
                <tr>
                  <th className="py-3 px-4 text-left font-medium text-gray-700">Date</th>
                  <th className="py-3 px-4 text-left font-medium text-gray-700">Type</th>
                  <th className="py-3 px-4 text-left font-medium text-gray-700">Brand</th>
                  <th className="py-3 px-4 text-left font-medium text-gray-700">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr>
                  <td className="py-4 px-4">April 2, 2025</td>
                  <td className="py-4 px-4">Franchise Inquiry</td>
                  <td className="py-4 px-4">Sulthan's Biryani</td>
                  <td className="py-4 px-4">
                    <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                      In Review
                    </span>
                  </td>
                </tr>
                <tr>
                  <td className="py-4 px-4">March 15, 2025</td>
                  <td className="py-4 px-4">Contact Message</td>
                  <td className="py-4 px-4">FunzXtreme</td>
                  <td className="py-4 px-4">
                    <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                      Responded
                    </span>
                  </td>
                </tr>
                <tr>
                  <td className="py-4 px-4">February 28, 2025</td>
                  <td className="py-4 px-4">Franchise Inquiry</td>
                  <td className="py-4 px-4">CHEAPNBEST</td>
                  <td className="py-4 px-4">
                    <span className="bg-purple-100 text-purple-800 px-2 py-1 rounded-full text-xs font-medium">
                      Meeting Scheduled
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;