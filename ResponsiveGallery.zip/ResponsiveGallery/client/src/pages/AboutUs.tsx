import React from 'react';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import TeamSection from '@/components/about/TeamSection';

const AboutUs: React.FC = () => {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative">
        <div className="bg-[#121212] h-[40vh] md:h-[50vh] relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-[#121212] via-transparent to-[#121212] z-10"></div>
          <AspectRatio ratio={16/9} className="h-full">
            <img 
              src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&q=80" 
              alt="Business team members in a meeting" 
              className="object-cover h-full w-full"
            />
          </AspectRatio>
          <div className="absolute inset-0 flex items-center z-20">
            <div className="container mx-auto px-6 md:px-12">
              <h1 className="font-cinzel text-4xl md:text-6xl font-bold gold-text mb-4 tracking-wide">
                WELCOME TO SPR GLOBAL
              </h1>
              <p className="text-white max-w-2xl text-lg md:text-xl">
                Our Story, Our Mission, Our Vision
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6 md:px-12">
          <div className="flex flex-col md:flex-row gap-12">
            <div className="md:w-1/2">
              <h2 className="font-cinzel text-3xl md:text-4xl font-bold mb-6">
                <span className="text-[#D4AF37]">OUR</span> 
                <span className="text-[#121212]"> STORY</span>
              </h2>
              <p className="text-gray-700 mb-6 leading-relaxed">
                SPR Global began as a small family business in Chennai over two decades ago. What started as a single restaurant has evolved into a diverse portfolio of brands across multiple sectors, each embodying our commitment to quality and excellence.
              </p>
              <p className="text-gray-700 mb-6 leading-relaxed">
                Through years of dedication and a passion for creating exceptional customer experiences, we've grown from strength to strength, expanding our presence across India and beyond. Our journey has been marked by a constant pursuit of innovation, authenticity, and cultural celebration.
              </p>
              <p className="text-gray-700 leading-relaxed">
                Today, SPR Global stands as a testament to the power of vision, perseverance, and a deep respect for diverse traditions. Each of our brands tells a unique story while remaining connected by our core values and commitment to quality.
              </p>
            </div>
            
            <div className="md:w-1/2">
              <div className="grid grid-cols-2 gap-4">
                <div className="rounded-md overflow-hidden shadow-lg">
                  <AspectRatio ratio={1/1}>
                    <img 
                      src="https://images.unsplash.com/photo-1621234292753-56cfc2dc3628?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80" 
                      alt="SPR Global history" 
                      className="object-cover h-full w-full"
                    />
                  </AspectRatio>
                </div>
                <div className="rounded-md overflow-hidden shadow-lg">
                  <AspectRatio ratio={1/1}>
                    <img 
                      src="https://images.unsplash.com/photo-1542744173-05336fcc7ad4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80" 
                      alt="Business growth" 
                      className="object-cover h-full w-full"
                    />
                  </AspectRatio>
                </div>
                <div className="rounded-md overflow-hidden shadow-lg">
                  <AspectRatio ratio={1/1}>
                    <img 
                      src="https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80" 
                      alt="Team collaboration" 
                      className="object-cover h-full w-full"
                    />
                  </AspectRatio>
                </div>
                <div className="rounded-md overflow-hidden shadow-lg">
                  <AspectRatio ratio={1/1}>
                    <img 
                      src="https://images.unsplash.com/photo-1578574577315-3fbeb0cecdc2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80" 
                      alt="Modern business" 
                      className="object-cover h-full w-full"
                    />
                  </AspectRatio>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <h3 className="font-cinzel text-2xl font-bold mb-4 text-[#121212]">Our Mission</h3>
              <div className="w-16 h-1 bg-[#D4AF37] mb-6"></div>
              <p className="text-gray-700 leading-relaxed">
                To inspire and empower communities through innovative business concepts that celebrate cultural heritage while embracing modern expectations. We strive to create exceptional experiences that bring joy, value, and satisfaction to our customers while fostering growth and development for our team members and partners.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md">
              <h3 className="font-cinzel text-2xl font-bold mb-4 text-[#121212]">Our Vision</h3>
              <div className="w-16 h-1 bg-[#D4AF37] mb-6"></div>
              <p className="text-gray-700 leading-relaxed">
                To be a globally recognized business group known for excellence across diverse sectors, creating brands that stand for quality, innovation, and cultural authenticity. We aim to expand our footprint internationally while maintaining the core values that define us: integrity, passion, respect for tradition, and commitment to continuous improvement.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6 md:px-12">
          <h2 className="text-center font-playfair text-3xl md:text-4xl font-bold mb-4">OUR CORE VALUES</h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-12"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-gray-50 p-6 rounded-lg shadow-md border border-gray-100 text-center">
              <div className="bg-[#D4AF37] bg-opacity-20 p-4 rounded-full inline-flex mb-4">
                <svg className="w-8 h-8 text-[#D4AF37]" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Excellence</h3>
              <p className="text-gray-600">
                We strive for excellence in everything we do, from customer service to product quality.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-md border border-gray-100 text-center">
              <div className="bg-[#D4AF37] bg-opacity-20 p-4 rounded-full inline-flex mb-4">
                <svg className="w-8 h-8 text-[#D4AF37]" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"></path>
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Community</h3>
              <p className="text-gray-600">
                We value connection and aim to create spaces that bring people together.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-md border border-gray-100 text-center">
              <div className="bg-[#D4AF37] bg-opacity-20 p-4 rounded-full inline-flex mb-4">
                <svg className="w-8 h-8 text-[#D4AF37]" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd"></path>
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Innovation</h3>
              <p className="text-gray-600">
                We embrace change and constantly seek new ways to improve and evolve our offerings.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-md border border-gray-100 text-center">
              <div className="bg-[#D4AF37] bg-opacity-20 p-4 rounded-full inline-flex mb-4">
                <svg className="w-8 h-8 text-[#D4AF37]" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd"></path>
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Authenticity</h3>
              <p className="text-gray-600">
                We honor traditions and stay true to the cultural roots of our diverse brands.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <TeamSection />
    </div>
  );
};

export default AboutUs;
