import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import MainLayout from "./layouts/MainLayout";
import Home from "./pages/Home";
import AboutUs from "./pages/AboutUs";
import BusinessOpportunities from "./pages/BusinessOpportunities";
import Contact from "./pages/Contact";
import BrandDetails from "./pages/BrandDetails";
import Profile from "./pages/Profile";
import Auth from "./pages/Auth";
import NotFound from "@/pages/not-found";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <MainLayout>
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/about" component={AboutUs} />
            <Route path="/business-opportunities" component={BusinessOpportunities} />
            <Route path="/contact" component={Contact} />
            <Route path="/brands/:slug" component={BrandDetails} />
            <ProtectedRoute path="/profile" component={Profile} />
            <Route path="/auth" component={Auth} />
            <Route path="/auth/:tab" component={Auth} />
            <Route component={NotFound} />
          </Switch>
        </MainLayout>
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
